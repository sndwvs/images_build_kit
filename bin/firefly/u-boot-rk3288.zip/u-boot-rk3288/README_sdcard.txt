DEV=/path/to/sdcard

# flash IDB sector 0
dd if=idb_sector_0.enc of=${DEV} conv=sync,fsync seek=64

# flash IDB sector 1 (this is "boot" SD card, not "update" SD card)
dd if=idb_sector_1 of=${DEV} conv=sync,fsync seek=65

# flash DDR blob
dd if=FlashData.bin of=${DEV} conv=sync,fsync seek=68

# flash U-Boot
dd if=FlashBoot.bin of=${DEV} conv=sync,fsync seek=100

# flash parameter (physical offset 0x2000 == logical offset 0x0)
#dd if=parameter.img of=${DEV} conv=sync,fsync seek=$((0x2000+0x0))
#rkflashtool P < orig/parameter
#upgrade_tool di -p orig/parameter

# flash ${partition} image
#dd if=${partition}.img of=${DEV} conv=sync,fsync seek=$((0x2000+offset))
#rkflashtool w ${partition} < ${partition}.img
#upgrade_tool di ${partition} ${partition}.img
