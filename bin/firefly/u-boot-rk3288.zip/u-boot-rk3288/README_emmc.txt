upgrade_tool ul RK3288UbootLoader_V2.19.01.bin
