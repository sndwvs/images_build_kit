#!/bin/sh

dd if=orig/idb_sector_0 conv=sync | split -b 512 --filter='openssl rc4 -K 7c4e0304550509072d2c7b38170d1711' > idb_sector_0.enc

dd if=orig/32_LPDDR2_200MHz_LPDDR3_200MHz_DDR3_200MHz_20141007.bin conv=sync | split -b 512 --filter='openssl rc4 -K 7c4e0304550509072d2c7b38170d1711' > FlashData.bin

dd if=orig/u-boot.bin conv=sync | split -b 512 --filter='openssl rc4 -K 7c4e0304550509072d2c7b38170d1711' > FlashBoot.bin

rkcrc -p orig/parameter parameter.img
